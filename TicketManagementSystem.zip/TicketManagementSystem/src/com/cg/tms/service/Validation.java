package com.cg.tms.service;

public interface Validation {
	
		String ticketDescription="[a-zA-Z] {}";
		String ticketPriority="[1-3] {1}";
		String ticketStatus="[a-zA-Z] {}";
		public static boolean validatedata(String data, String pattern)
		{
			return data.matches(pattern);
		}
		
}
