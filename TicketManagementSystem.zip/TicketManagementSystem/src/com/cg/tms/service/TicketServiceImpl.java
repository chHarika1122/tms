package com.cg.tms.service;


//imports used
import java.util.List;

import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public class TicketServiceImpl implements TicketService{
	TicketDAO td = new TicketDAOImpl();  //creation of object

	
	
	//------------------------ 1. Sample Application for Layered Architecture --------------------------
	/*******************************************************************************************************
	 - Function Name	:	raisedNewTicket
	 - Input Parameters	:	ticketbean object
	 - Return Type		:	boolean
	 - Throws			:  	Exception
	 - Description		:	gets all the details into map and displays the values 
	 ********************************************************************************************************/
	
	


 public boolean raiseNewTicket(TicketBean ticketBean) {

 // TODO Auto-generated method stub
 return td.raiseNewTicket(ticketBean);  //return variable

 }

 
//------------------------ 1. Sample Application for Layered Architecture --------------------------
	/*******************************************************************************************************
	 - method : listTicketCategory
	 -description : details all taken into the list
	 ********************************************************************************************************/
	
 
 
 @Override

 public List<TicketCategory> listTicketCategory() {

 // TODO Auto-generated method stub

 return td.listTicketCategory();

 }

}

