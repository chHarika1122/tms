package com.cg.tms.dao;

//imports used

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.takeit.TakeIt;



public class TicketDAOImpl implements TicketDAO{

	Map<String, TicketBean> ticketLogMap = new HashMap<>();

	//Description of first method
 @Override

 public boolean raiseNewTicket(TicketBean ticketBean) {

 // TODO Auto-generated method stub

 ticketLogMap.put(ticketBean.getTicketno(), ticketBean);
TicketBean tb = ticketLogMap.get(ticketBean.getTicketno());

 if(tb!=null)
 return true;
 else
 return false;
 }


//second method
 @Override

 public List<TicketCategory> listTicketCategory() {

 // TODO Auto-generated method stub

    int i=1;

 //Getting Collection of values from HashMap

    List<TicketCategory> ticklist = new ArrayList<>();
for(Entry<String,String> entry: TakeIt.getTicketCategoryEntries().entrySet()) {
String str = ""+i;
String str1= entry.getValue();
TicketCategory tc = new TicketCategory(str,str1);
str="";
i++;
ticklist.add(tc);
}
return ticklist;

}
}

