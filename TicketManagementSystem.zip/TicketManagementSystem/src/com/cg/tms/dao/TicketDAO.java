package com.cg.tms.dao;

//imports used in this interface
import java.util.List;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

//interface with methods 
public interface TicketDAO {
public boolean raiseNewTicket(TicketBean ticketBean);
List<TicketCategory>listTicketCategory();

}

