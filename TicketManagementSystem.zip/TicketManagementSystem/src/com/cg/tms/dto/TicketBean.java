package com.cg.tms.dto;
public class TicketBean {
	
	//Declaring of variables 
	
private String ticketno;

 private String ticketCategoryId;

 private String ticketDescription;

 private String ticketPriority;

 private String ticketStatus;

 private String timcom;

 public TicketBean() {

 // TODO Auto-generated constructor stub

 }
//constructor starts 
 public TicketBean(String ticketno, String ticketCategoryId, String ticketDescription, String ticketPriority)

 {

 this.ticketno = ticketno;

 this.ticketCategoryId = ticketCategoryId;

 this.ticketDescription = ticketDescription;

 this.ticketPriority = ticketPriority;

 }
//constructor ends
 
 //start of getters and setters 
 public String getTicketno() {

 return ticketno;

 }

 public void setTicketno(String ticketno) {

 this.ticketno = ticketno;

 }

 public String getTicketCategoryId() {

 return ticketCategoryId;

 }

 public void setTicketCategoryId(String ticketCategoryId) {

 this.ticketCategoryId = ticketCategoryId;

 }

 public String getTicketDescription() {

 return ticketDescription;

 }

 public void setTicketDescription(String ticketDescription) {

 this.ticketDescription = ticketDescription;

 }

 public String getTicketPriority() {

 return ticketPriority;

 }

 public void setTicketPriority(String ticketPriority) {

 this.ticketPriority = ticketPriority;

 }

 public String getTicketStatus() {

 return ticketStatus;

 }

 public void setTicketStatus(String ticketStatus) {

 this.ticketStatus = ticketStatus;

 }

 public String gettimcom() {

 return timcom;

 }

 public void settimcom(String timcom) {

 this.timcom = timcom;

 }
//end of getters and setters
 
 //to convert to string
 @Override

 public String toString() {

 return "ticketno=" + ticketno + "\n ticketCategoryId=" + ticketCategoryId + "\n ticketDescription="

  + ticketDescription + "\n ticketPriority=" + ticketPriority + "\n ticketStatus=" + ticketStatus

  + "\n timcom=" + timcom;

 }



}

