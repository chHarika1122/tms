package com.cg.tms.dto;
public class TicketCategory {

//declaring variables
 private String ticketCategoryId;

 private String categoryName;
 
//constructor of class
 
 public TicketCategory() {

 // TODO Auto-generated constructor stub

 }
//end of constructor

//Constructor2 starts
 public TicketCategory(String ticketCategoryId, String categoryName) {

 super();

 this.ticketCategoryId = ticketCategoryId;

 this.categoryName = categoryName;

 }

//End of constructor2

 
 //start of getters and setters
 public String getTicketCategoryId() {

 return ticketCategoryId;

 }
public void setTicketCategoryId(String ticketCategoryId) {

 this.ticketCategoryId = ticketCategoryId;

 }
 public String getCategoryName() {

 return categoryName;

 }
 public void setCategoryName(String categoryName) {

 this.categoryName = categoryName;

 }

//End of getters and setters 

 
 //To change to string 
 @Override

 public String toString() {

 return "TicketCategory [ticketCategoryId=" + ticketCategoryId + ", categoryName=" + categoryName + "]";

 }



}

